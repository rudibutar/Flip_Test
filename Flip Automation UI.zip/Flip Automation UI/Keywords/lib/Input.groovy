package lib

import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject

import java.util.concurrent.ConcurrentHashMap.KeySetView

import com.kms.katalon.core.annotation.Keyword
import com.kms.katalon.core.checkpoint.Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.testcase.TestCase
import com.kms.katalon.core.testdata.TestData
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.webui.common.WebUiCommonHelper

import internal.GlobalVariable

import org.openqa.selenium.By
import org.openqa.selenium.JavascriptExecutor
import org.openqa.selenium.Keys
import org.openqa.selenium.WebDriver as WebDriver
import org.openqa.selenium.WebElement
import org.openqa.selenium.remote.server.handler.SendKeys
import org.openqa.selenium.support.ui.ExpectedConditions
import org.openqa.selenium.support.ui.WebDriverWait

import com.kms.katalon.core.webui.driver.DriverFactory as DriverFactory

public class Input {

	public static byXpath(String xpath, String value){

		//DelaySetting delaySetting = new DelaySetting()
		WebDriver driver = DriverFactory.getWebDriver()
		//Thread.sleep(1000)
		for(int i = 0; i < value.length(); i++){
			String c = value.charAt(i)
			driver.findElement(By.xpath(xpath)).sendKeys(c)
			//Thread.sleep(1000)
			//Thread.sleep(delaySetting.geDelay("input"))
		}
		//Thread.sleep(1000)
	}

	public static byId(String id, String value){

		//DelaySetting delaySetting = new DelaySetting()
		WebDriver driver = DriverFactory.getWebDriver()
		//Thread.sleep(1000)
		for(int i = 0; i < value.length(); i++){
			String c = value.charAt(i)
			driver.findElement(By.id(id)).sendKeys(c)
			//Thread.sleep(1000)
			//Thread.sleep(delaySetting.geDelay("input"))
		}
		//Thread.sleep(1000)
	}
	
	public static byIdInteger(String id, String value){

		//DelaySetting delaySetting = new DelaySetting()

		WebDriver driver = DriverFactory.getWebDriver()
		WebElement element = driver.findElement(By.id(id))
		JavascriptExecutor js = (JavascriptExecutor) driver
		js.executeScript("arguments[0].value = arguments[1];", element, value)
	}		
	
	//public static byDOB(String xpathDate, String xpathMonth, String xpathYear, String date, String month, String year){
	public static byDOB(String shadowSelector, String xpath, String value){
		
		//DelaySetting delaySetting = new DelaySetting()

		WebDriver driver = DriverFactory.getWebDriver()
		WebElement shadowHost = driver.findElement(By.cssSelector(shadowSelector))
		JavascriptExecutor js = (JavascriptExecutor) driver
		
		WebElement shadowRoot = (WebElement) js.executeScript("return arguments[0].shadowRoot", shadowHost)
		WebElement shadowField = shadowRoot.findElement(By.xpath(xpath))
		
		//WebElement element = driver.findElement(By.id(id))
		//JavascriptExecutor js = (JavascriptExecutor) driver
		js.executeScript("arguments[0].value = arguments[1];", shadowField, value)
		
//		WebElement elementDate = driver.findElement(By.xpath(xpathDate))
//		WebElement elementMonth = driver.findElement(By.xpath(xpathMonth))
//		WebElement elementYear = driver.findElement(By.xpath(xpathYear))
//		elementDate.sendKeys(date)
//		elementDate.sendKeys(Keys.ARROW_RIGHT)
//		Thread.sleep(2000)
//		elementMonth.sendKeys(month)
//		elementMonth.sendKeys(Keys.ARROW_RIGHT)
//		Thread.sleep(2000)
//		elementYear.sendKeys(year)
	}
	
	public static byDay(String id, String day){
		
				//DelaySetting delaySetting = new DelaySetting()
		
		WebDriver driver = DriverFactory.getWebDriver()
		WebElement dateInput = driver.findElement(By.id(id));
		dateInput.click();

		// Wait until the date picker is displayed
		WebDriverWait wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("mt-1 block w-full py-2 px-3 border border-gray-300 rounded-md shadow-sm")));

		// Adjust the year and month using spinbuttons or similar controls
		// Example: navigate to July 2024

		// Increment year until 2024 is displayed
		WebElement yearSpinButton = driver.findElement(By.xpath("//*[@id='dob']//div/div/div[5] and aria-label='year'"));
		while (!driver.findElement(By.xpath("//*[@id='dob']//div/div/div[5]")).getText().equals("2020")) {
			yearSpinButton.click();
		}

		// Adjust month to July
		WebElement monthSpinButton = driver.findElement(By.xpath("//*[@id='dob']//div/div/div[3] and @aria-label='month'"));
		while (!driver.findElement(By.xpath("//*[@id='dob']//div/div/div[3]")).getText().equals("July")) {
			monthSpinButton.click();
		}

		// Adjust month to July
		WebElement daySpinButton = driver.findElement(By.xpath("//*[@id='dob']//div/div/div[1] and @aria-label='day'"));
		while (!driver.findElement(By.xpath("//*[@id='dob']//div/div/div[1]")).getText().equals("16")) {
			daySpinButton.click();
		}
//		// Select the day (30th in this case)
//		WebElement day = driver.findElement(By.xpath("//*[@id='dob']//div/div/div[1]"));
//		day.click();
//				driver.findElement(By.id(id)).sendKeys(c)
	}

}
